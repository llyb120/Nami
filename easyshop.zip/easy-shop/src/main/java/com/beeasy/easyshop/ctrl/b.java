package com.beeasy.easyshop.ctrl;

public class b {
    public String word = "粗鄙";
}
