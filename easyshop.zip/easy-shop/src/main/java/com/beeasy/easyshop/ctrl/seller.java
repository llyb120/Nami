//package com.beeasy.easyshop.ctrl;
//
//import com.beeasy.web.core.R;
//
//public class seller {
//
//    public R login(String username, String password){
//
//    }
//}
