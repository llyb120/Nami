package com.beeasy.easyshop.ctrl;

public class e {

    public String rile = "e teffffee chan13321ged";


}
