package com.beeasy.easyshop.ctrl;


import com.beeasy.web.core.R;

public class auth {

    public R login(){
        return null;
    }
}
