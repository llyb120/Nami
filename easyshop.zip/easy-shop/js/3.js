console.log("3.js fuck 3324+2")
require("./4.js")